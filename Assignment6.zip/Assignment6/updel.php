<?php

$username1=$_POST['username'];
$password1=$_POST['password'];
$name1=$_POST['name'];
$country1=$_POST['country'];
$bio1=$_POST['bio'];
$role1=$_POST['role'];

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "student";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if($_POST['delete']){
$sql = "delete FROM mytable1 where username='$username1';";
if ($conn->query($sql) === TRUE) 
{ 
	header("Location:admin.php");
		  
} 
}
 
if($_POST['update']){
$sql = "update mytable1 set password='$password1',Name='$name1',Country='$country1',Bio='$bio1',Role='$role1' where username='$username1';";
if ($conn->query($sql) === TRUE) 
{ 
	header("Location:admin.php");
		  
} 
}
mysqli_close($conn);
?> 