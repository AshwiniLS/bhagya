<?php

$username1=$_POST["username"];
$password1=$_POST["password"];


$servername="localhost";
$username="root";
$password="";
$dbname="student";

$conn=mysql_connect($servername,$username,$password,$bdname);

$sql="select password,role from mytable1 where username='$username1';";
$result=mysqli_query($conn,$sql);


if (mysql_num_rows($result) >0) 
{
while($row=mysqli_fetch_assoc($result))
{
	if($password1==$row["password"] &&$row["role"]=='admin')
	{
		header("Location:admin.php");

     elseif($password1==$row["password"] && $row["role"]=='user')
	{
		header("Location:home.php");
		}
		else
		{
			echo "Password is in correct";
			}
			}
			}
			else
			{
				echo "user does not exists";
				}
				conn->close();



				?>