<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "student";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "SELECT * FROM mytable1";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) 
{
    while($row = mysqli_fetch_assoc($result)) {
        echo  "<form method='post' action='updel.php'><table border='1'>
				<tr><th>USERNAME</th><th>PASSWORD</th><th>NAME</th><th>COUNTRY</th><th>BIO</th><th>ROLE</th><th colspan='2'>ACTION</th> </tr>
				<tr><td><input type='text' name='username' value=".$row['username']." readonly/></td>
				<td><input type='text' name='password' value=".$row['password']."></td>
				<td><input type='text' name='name' value=".$row['Name']."></td>
				<td><input type='text' name='country' value=".$row['Country']."></td>
				<td><input type='text' name='bio' value=".$row['Bio']."></td>
				<td><input type='text' name='role' value=".$row['Role']."></td>
				<td><input type='submit' name='update' value='update'/></td><td><input type='submit' name='delete' value='delete'/></td>
				</tr></table><br></form></body>" ;
				
    }
} else {
	//$sql = Update mytable set  where username=".$row['username'].";
	//$result = mysqli_query($conn, $sql);
    echo "0 results";
}

mysqli_close($conn);
?> 