<?php

$username1=$_POST['username'];

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "student";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if($_POST['delete'])
{
echo "delete";
}
if($_POST['update'])
{
echo "update";
}
$sql = "delete FROM mytable1 where username='$username1';";

if ($conn->query($sql) === TRUE) 
{ 
	//header("Location:admin.php");
		  
} else 
{
    echo "0 results";
}

mysqli_close($conn);
?> 